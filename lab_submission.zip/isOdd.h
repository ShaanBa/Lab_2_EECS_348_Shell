#ifndef ISODD_H
#define ISODD_H

// Function prototype for isOdd
int isOdd(int num);

#endif // ISODD_H